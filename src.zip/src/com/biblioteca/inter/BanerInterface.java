package com.biblioteca.inter;

public interface BanerInterface {

    void showOptions();

}
