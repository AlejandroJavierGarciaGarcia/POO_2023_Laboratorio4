package com.biblioteca.inter;

public interface SelectionInterface {


    void addResource(String typeResource);

    void clearResource();


}
