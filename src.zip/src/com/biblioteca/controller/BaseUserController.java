package com.biblioteca.controller;

public class BaseUserController {
}
