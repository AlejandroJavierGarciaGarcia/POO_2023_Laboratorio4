package com.biblioteca.controller;

public class PremiumController {
}
