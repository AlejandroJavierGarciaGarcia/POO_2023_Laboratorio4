package com.biblioteca.manager;

import java.util.HashMap;
import java.util.Map;

public class UserManager {
    private Map<String, String> userCredentials = new HashMap<>();

    public void addUser(String username, String password) {
        userCredentials.put(username, password);
    }

    public boolean checkUser(String username, String password) {
        return userCredentials.containsKey(username) && userCredentials.get(username).equals(password);
    }

    public void loadUsers() {

    }
}
