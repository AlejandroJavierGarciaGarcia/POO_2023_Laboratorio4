package com.biblioteca.system;

public class Main {
    public static void main(String[] args) {

    }
}