package com.biblioteca.bean;

public class Book {


}
